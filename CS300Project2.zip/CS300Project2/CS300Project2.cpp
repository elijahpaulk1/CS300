#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sstream>

class Course {
public:
    std::string courseNumber;
    std::string courseTitle;
    std::vector<std::string> prerequisites;

    Course(const std::string& number, const std::string& title) : courseNumber(number), courseTitle(title) {}

    void addPrerequisite(const std::string& prereq) {
        prerequisites.push_back(prereq);
    }
};

std::vector<Course> courseList;
std::string courseNumber; // Declare courseNumber outside the switch statement

// Function to load data from a file into the data structure
void loadDataStructure(const std::string& fileName) {
    // Clear the existing courseList
    courseList.clear();

    // Open the file for reading
    std::ifstream file(fileName);
    if (!file.is_open()) {
        std::cerr << "Error: Unable to open the file." << std::endl;
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        // Split the line into tokens using ',' as a delimiter
        std::istringstream ss(line);
        std::string courseNumber, courseTitle, prereq;

        std::getline(ss, courseNumber, ',');
        std::getline(ss, courseTitle, ',');

        Course newCourse(courseNumber, courseTitle);

        while (std::getline(ss, prereq, ',')) {
            newCourse.addPrerequisite(prereq);
        }

        courseList.push_back(newCourse);
    }

    file.close();
}

// Function to print a list of courses in alphanumeric order
void printCourseList() {
    // Sort the courseList based on courseNumber
    std::sort(courseList.begin(), courseList.end(), [](const Course& a, const Course& b) {
        return a.courseNumber < b.courseNumber;
    });

    std::cout << "Here is a sample schedule:\n";
    for (const Course& course : courseList) {
        std::cout << course.courseNumber << ", " << course.courseTitle << "\n";
    }
}

// Function to print course information by courseNumber
void printCourse() {
    for (const Course& course : courseList) {
        if (course.courseNumber == courseNumber) {
            std::cout << course.courseNumber << ", " << course.courseTitle << " Prerequisites: ";
            for (const std::string& prereq : course.prerequisites) {
                std::cout << prereq << ", ";
            }
            std::cout << std::endl;
            return;
        }
    }
    std::cerr << "Course not found." << std::endl;
}

int main() {
    int choice;
    std::string fileName;

    std::cout << "Welcome to the course planner.\n";

    do {
        std::cout << "1. Load Data Structure\n";
        std::cout << "2. Print Course List\n";
        std::cout << "3. Print Course\n";
        std::cout << "9. Exit\n";
        std::cout << "What would you like to do? ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter the file name: ";
                std::cin >> fileName;
                loadDataStructure(fileName);
                break;
            case 2:
                printCourseList();
                break;
            case 3:
                std::cout << "What course do you want to know about? ";
                std::cin >> courseNumber; // Moved inside the case 3
                printCourse();
                break;
            case 9:
                std::cout << "Thank you for using the course planner!\n";
                break;
            default:
                std::cerr << choice << " is not a valid option.\n";
        }
    } while (choice != 9);

    return 0;
}